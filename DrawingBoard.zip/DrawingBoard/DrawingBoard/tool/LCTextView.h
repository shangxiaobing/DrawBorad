//
//  LCTextView.h
//  LoveChineseForTeacher
//
//  Created by YXZT on 16/12/16.
//  Copyright © 2016年 YXZT. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LCTextView : UITextView

@property (copy,nonatomic) NSString *placeholder;

@property (strong,nonatomic) UIColor *placeholderColor;
@end
