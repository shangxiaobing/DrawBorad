//
//  HomeViewController.m
//  Painter
//
//  Created by  ibokan on 10-9-7.
//  Copyright 2010 tencent.com. All rights reserved.
//

#import "HomeViewController.h"

#import "DrawNotesViewController.h"
#import "PainterView.h"
#import "LCTextView.h"
#import <CoreText/CoreText.h>

@interface HomeViewController ()<UIAlertViewDelegate,UITextViewDelegate>
{
    int    index;
    BOOL   isShowTab;
    BOOL   isShowColor;
    UIView * shareView;
    UIButton * btnTag;
    UIButton * btnClear;
    UIButton * btnFinish;
    UIButton * btnColor;
    UIButton * btnNotes;
    UIScrollView * scCollor;
    
    NSMutableArray * pintArray;
    
    LCTextView *contentTextView;
    
}

@property (nonatomic, strong)UIView *buttomView;

@end

@implementation HomeViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self initMine];
    
}

-(void)initMine
{
    pintArray = [NSMutableArray array];
    self.view.backgroundColor = [UIColor whiteColor];
    
    CGRect rectC = CGRectMake(0, 20, self.view.frame.size.width, self.view.frame.size.height-20-50);
    contentTextView = [[LCTextView alloc]initWithFrame:rectC];
    [contentTextView becomeFirstResponder];
    contentTextView.font = [UIFont systemFontOfSize:30];
    contentTextView.inputView = [[UIView alloc]initWithFrame:CGRectZero];
    [self.view addSubview:contentTextView];
    
    CGRect rectI = CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height-20-50);
    UIImageView *imageView = [[UIImageView alloc] initWithFrame:rectI];
    imageView.image = [UIImage imageNamed:@"pagesLine"];
    [contentTextView addSubview:imageView];
    [contentTextView sendSubviewToBack:imageView];
    
    CGRect rectP = CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height);
    _painterView = [[PainterView alloc] initWithFrame:rectP];
    __weak typeof (self)weakSelf = self;
    _painterView.finishBlock = ^{
        [weakSelf endFinish];
    };
    _painterView.beginPaintBlock = ^{
        [weakSelf beginPaint];
    };
    _painterView.beginEditingBlock = ^{
        [weakSelf beginEditing];
    };
    [self.view addSubview:_painterView];
    
    [self.view addSubview:self.buttomView];
}

-(void)beginPaint
{
    _painterView.userInteractionEnabled = YES;
}

-(void)beginEditing
{
    _painterView.userInteractionEnabled = NO;
    [self performSelector:@selector(beginPaint) withObject:nil afterDelay:0.5];
}


-(void)endFinish
{
    NSMutableArray *arr = _painterView.finishSquiggles;
    CGFloat minX = 0.0;
    CGFloat minY = 0.0;
    CGFloat maxX = 0.0;
    CGFloat maxY = 0.0;
    NSInteger index = 0;
    for(Squiggle *squiggle in arr)
    {
        for (int i = 0; i<squiggle.pointsXArray.count; i++) {
            CGFloat x = [squiggle.pointsXArray[i] floatValue];
            CGFloat y = [squiggle.pointsYArray[i] floatValue];
            index++;
            if (index==1) {
                minX = x;
                maxX = x;
                minY = y;
                maxY = y;
            }else{
                if (x<minX) {
                    minX = x;
                }
                if (x>maxX) {
                    maxX = x;
                }
                if (y<minY) {
                    minY = y;
                }
                if (y>maxY) {
                    maxY = y;
                }
            }
        }
    }
    [pintArray addObject:[_painterView screenshot]];
    UIImage *image = [_painterView screenshotWithRect:CGRectMake(minX-2, minY-2, maxX-minX+4, maxY-minY+4)];
    
    CGFloat scale = image.size.width/image.size.height;
    
    UIImage *resultImage;
    NSInteger mMaxW = 42;
    NSInteger mMaxH = 40;
    if (image.size.height>mMaxH||image.size.width>mMaxW) {
        CGFloat imageW = 0;
        CGFloat imageH = 0;
        if (image.size.width>mMaxW) {
            if (image.size.height>mMaxH) {
                imageH = mMaxH;
                imageW = imageH*scale;
                
                CGSize size = CGSizeMake(imageW, imageH);
                //                    UIGraphicsBeginImageContext(size);
                UIGraphicsBeginImageContextWithOptions(size, NO, [UIScreen mainScreen].scale);
                [image drawInRect:CGRectMake(0, 0, size.width, size.height)];
                resultImage= UIGraphicsGetImageFromCurrentImageContext();
                UIGraphicsEndImageContext();
            }else{
                imageW = mMaxW;
                imageH = mMaxW/scale;
                
                CGSize size = CGSizeMake(imageW, imageH);
                //                    UIGraphicsBeginImageContext(size);
                UIGraphicsBeginImageContextWithOptions(size, NO, [UIScreen mainScreen].scale);
                [image drawInRect:CGRectMake(0, 0, size.width, size.height)];
                resultImage= UIGraphicsGetImageFromCurrentImageContext();
                UIGraphicsEndImageContext();
            }
        }else{
            if (image.size.height>mMaxH) {
                imageH = mMaxH;
                imageW = imageH*scale;
                
                CGSize size = CGSizeMake(imageW, imageH);
                //                    UIGraphicsBeginImageContext(size);
                UIGraphicsBeginImageContextWithOptions(size, NO, [UIScreen mainScreen].scale);
                [image drawInRect:CGRectMake(0, 0, size.width, size.height)];
                resultImage= UIGraphicsGetImageFromCurrentImageContext();
                UIGraphicsEndImageContext();
            }else{
                resultImage = image;
            }
        }
    }else{
        resultImage = image;
    }
    
    [pintArray addObject:resultImage];
    [_painterView resetView];
    
    
    NSMutableAttributedString *string = [[NSMutableAttributedString alloc] initWithAttributedString:contentTextView.attributedText];
    NSTextAttachment *textAttachment = [[NSTextAttachment alloc] initWithData:nil ofType:nil] ;
    textAttachment.image = resultImage; //要添加的图片
    NSAttributedString *textAttachmentString = [NSAttributedString attributedStringWithAttachment:textAttachment] ;
    CGFloat location = contentTextView.selectedRange.location;
    [string insertAttributedString:textAttachmentString atIndex:(NSUInteger)location];//index为用户指定要插入图片的位置
    
    contentTextView.attributedText = string;
    
    contentTextView.selectedRange = NSMakeRange(location+1, 0);
}


-(void)clickMenuButton:(UIButton *)sender
{
    NSMutableAttributedString *string = [[NSMutableAttributedString alloc] initWithAttributedString:contentTextView.attributedText];
    CGFloat location = contentTextView.selectedRange.location;
    
    if (sender.tag==0) {//空格
        [string insertAttributedString:[[NSAttributedString alloc]initWithString:@" "] atIndex:(NSInteger)location];
        contentTextView.attributedText = string;
        contentTextView.selectedRange = NSMakeRange(location+1, 0);
    }else if (sender.tag==1){//换行
        [string insertAttributedString:[[NSAttributedString alloc]initWithString:@"\n"] atIndex:(NSInteger)location];
        contentTextView.attributedText = string;
        contentTextView.selectedRange = NSMakeRange(location+@"\n".length, 0);
    }else{//删除
        if (location<1) {
            return;
        }
        NSAttributedString *mu1 = [string attributedSubstringFromRange:NSMakeRange(0, location-1)];
        NSAttributedString *mu2 = [string attributedSubstringFromRange:NSMakeRange(location, string.length-location)];
        if (mu2.length==0) {
            mu2 = [[NSAttributedString alloc]initWithString:@""];
        }
        NSMutableAttributedString *muAtt = [[NSMutableAttributedString alloc]initWithAttributedString:mu1];
        [muAtt appendAttributedString:mu2];
        contentTextView.attributedText = [[NSAttributedString alloc]initWithAttributedString:muAtt];
        if (location>0) {
            contentTextView.selectedRange = NSMakeRange(location-1, 0);
        }else{
            contentTextView.selectedRange = NSMakeRange(0, 0);
        }
    }
    [self beginPaint];
}


#pragma mark - 懒加载
-(UIView *)buttomView
{
    if (!_buttomView) {
        _buttomView = [[UIView alloc]initWithFrame:CGRectMake(0, self.view.frame.size.height-50, self.view.frame.size.width, 50)];
        NSArray *arr = @[@"空格",@"换行",@"删除"];
        CGFloat width = self.view.frame.size.width/arr.count;
        for (int i = 0; i<arr.count; i++) {
            UIButton *button = [[UIButton alloc]initWithFrame:CGRectMake(i*width, 0, width, 50)];
            button.titleLabel.font = [UIFont systemFontOfSize:15];
            button.tag = i;
            [button setTitle:arr[i] forState:UIControlStateNormal];
            [button setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
            [button addTarget:self action:@selector(clickMenuButton:) forControlEvents:UIControlEventTouchUpInside];
            [_buttomView addSubview:button];
        }
    }
    return _buttomView;
}





@end
